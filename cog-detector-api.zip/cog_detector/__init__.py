__all__ = ['cog_detector']
